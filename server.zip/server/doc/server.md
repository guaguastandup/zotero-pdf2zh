# server.py

## 虚拟环境

本脚本会自动尝试运行`uv`或`conda`来进行环境配置, 当切换翻译引擎`pdf2zh`/`pdf2zh_next`时, 也会切换虚拟环境
